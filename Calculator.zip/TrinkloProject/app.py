from tkinter import *
import parser

i=0

def getvairbale(num):
    global i
    display.insert(i,num)
    i+=1

def getOperators(operators):
    global i
    length = len(operators)
    display.insert(i,operators)
    i+=length

def clearAll():
    display.delete(0,END)

def undo():
    entireString = display.get()
    if len(entireString):
        new_string =entireString[:-1]
        clearAll()
        display.insert(0,new_string)
    else:
        clearAll()
        display.insert(0,"404 NOT FOUND")

def Calculate():
    entire_string =display.get()
    try:
        a = parser.expr(entire_string).compile()
        result = eval(a)
        clearAll()
        display.insert(0,result)
    except EXCEPTION:
        clearAll()
        display(0,"error")

def factorial():

    num=0
    factorial = 1
    if num < 0:
        clearAll()
        print("0")
    elif num == 0:
        clearAll()
        print("0")
    else:
        for i in range(1, num + 1):
            factorial = factorial * i
            clearAll()
        display(0,factorial)





root = Tk()

display = Entry(root)
display.grid(row=1, columnspan=6, sticky=W+E)

Button(root, text="1", command=lambda: getvairbale(1)).grid(row=2, column=0)
Button(root, text="2", command=lambda: getvairbale(2)).grid(row=2, column=1)
Button(root, text="3", command=lambda: getvairbale(3)).grid(row=2, column=2)

Button(root, text="4", command=lambda: getvairbale(4)).grid(row=3, column=0)
Button(root, text="5", command=lambda: getvairbale(5)).grid(row=3, column=1)
Button(root, text="6", command=lambda: getvairbale(6)).grid(row=3, column=2)

Button(root, text="7", command=lambda: getvairbale(7)).grid(row=4, column=0)
Button(root, text="8", command=lambda: getvairbale(8)).grid(row=4, column=1)
Button(root, text="9", command=lambda: getvairbale(9)).grid(row=4, column=2)

Button(root, text="AC", command=lambda: clearAll()).grid(row=5, column=0)
Button(root, text="0", command=lambda: getvairbale(0)).grid(row=5, column=1)
Button(root, text="=", command=lambda: Calculate()).grid(row=5, column=2)

Button(root, text="+", command=lambda:getOperators("+")).grid(row=2, column=3)
Button(root, text="-", command=lambda:getOperators("-")).grid(row=3, column=3)
Button(root, text="*", command=lambda:getOperators("*")).grid(row=4, column=3)
Button(root, text="/", command=lambda:getOperators("/")).grid(row=5, column=3)


Button(root, text="Pi", command=lambda:getOperators("*3.14")).grid(row=2, column=4)
Button(root, text="%", command=lambda:getOperators("%")).grid(row=3, column=4)
Button(root, text="(", command=lambda:getOperators("(")).grid(row=4, column=4)
Button(root, text="exp", command=lambda:getOperators("**")).grid(row=5, column=4)

Button(root, text="C", command=lambda: undo()).grid(row=2, column=5)
Button(root, text="X!", command=lambda: factorial()).grid(row=3, column=5)
Button(root, text=")", command=lambda:getOperators(")")).grid(row=4, column=5)
Button(root, text="x^2", command=lambda:getOperators("**2")).grid(row=5, column=5)






root.mainloop()
